import React, { Component } from 'react';

import Home from '.container/AboutContainer';
import Home from '.container/HomeContainer';
import Home from '.container/ContactContainer';


class App extends Component {
  render() {
    return (
      <About />
      <Home />
      <Contact />
    );
  }
}

export default App;
