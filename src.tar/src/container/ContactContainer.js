import React, { Component } from React;

export default class ContactContainer extends Component {
    render() {
        return (
            <div>
                <h1>Contact</h1>
            </div>
        )
    }
}